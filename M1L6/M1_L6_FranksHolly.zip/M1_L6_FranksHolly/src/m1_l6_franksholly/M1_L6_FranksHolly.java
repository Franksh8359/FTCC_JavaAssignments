/**
* Here is lab 6 from module 1 (Charge Account Validation) using NetBeans!
* 8-28-2017
* CSC 251 Lab 6 - Charge Account Validation
* @author Holly Franks
*/
package m1_l6_franksholly;
import javax.swing.JOptionPane;

public class M1_L6_FranksHolly {
   
    
    public static void main(String[] args) 
    {
         boolean validNum = false;
         String input;
         int accountNum = 0;
         AccountValidation av = new AccountValidation();
         
         while (validNum == false)
         {
             input = JOptionPane.showInputDialog("Enter the account number: ");
             
             try 
             {
                 accountNum = Integer.parseInt(input);
             }
             catch(Exception e) 
             {
                 if (input == null) {System.exit(0);} //if user clicks exit or cancel
             }
             
            validNum = av.validateAccountNum(accountNum);
         
            if (validNum == true) {JOptionPane.showMessageDialog(null, 
                                       "The account number\n" + accountNum +
                                                        "\nis valid!");}
            else {JOptionPane.showMessageDialog(null, 
                                        "The account number\n" + input + 
                                                "\nis not valid.\n" +
                                                "Please try again.");}
         }
         
         System.exit(0);   
    }    
}