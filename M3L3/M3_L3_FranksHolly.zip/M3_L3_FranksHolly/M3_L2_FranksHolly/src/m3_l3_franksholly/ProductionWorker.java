/**
* Here is the ProductionWorker class.
* 10-11-2017
* CSC 251 Lab 9 - Employee and ProductionWorker Classes 
* @author Holly Franks
*/
package m3_l3_franksholly;
import java.text.DecimalFormat;

public class ProductionWorker extends Employee {
    
    private int shift;
    private double hourlyRate;
    
    public ProductionWorker()
    {
        super("", "", "");
        shift = 0;
        hourlyRate = 0.0;
    }
    
    public ProductionWorker(String n, String num, String date, int sh, double r)
    {
        super(n, num, date);
        shift = sh;
        hourlyRate = r;
    }
    
    public void setShift(int sh) {shift = sh;}
    public void setHourlyRate(double rate) {hourlyRate = rate;}
    
    public int getShift() {return shift;}
    public double getHourlyrate() {return hourlyRate;}
    
    public String toString()
    {
        String shiftName;
        DecimalFormat dollar = new DecimalFormat("#,##0.00");
        
        if (shift == 1) {shiftName = "Day";}
        else if (shift == 2) {shiftName = "Night";}
        else {shiftName = "N/A";}
        
        return super.toString() +
                "\nShift: " + shiftName + "\nHourly Rate: $" + 
                dollar.format(hourlyRate);
    }   
}
