/**
* Here is the Employee & ProductionWorker Classes assignment from module 3.
* 10-11-2017
* CSC 251 Lab 9 - Employee and ProductionWorker Classes 
* @author Holly Franks
*/
package m3_l3_franksholly;
import java.util.Scanner;

public class M3_L3_FranksHolly {

    public static void main(String[] args) {

        String input, name, number, hireDate;
        int shift;
        double rate;
        Scanner kb = new Scanner(System.in);
        
        System.out.print("Please enter the following information for the worker: ");
        
        //worker name input
        System.out.print("\nName: ");
        name = kb.nextLine();
        
        //worker employee number input; has to be validated
        //if invalid, prompt the user to try again
        System.out.print("Employee Number: ");
        number = kb.nextLine();
        while (!ValidateEmpNum(number))
        {
            System.out.print("Invalid employee number." +
                    "\nPlease enter in the XXX-L format where X is a digit 0-9 "
                    + "and L is a letter A-M.\n"
                    + "\nEmployee Number: ");
            number = kb.nextLine();            
        }
        
        //worker hired date input
        System.out.print("Date Hired: ");
        hireDate = kb.nextLine();
        
        //worker shift input; has to be validated as 1 or 2
        //if not 1 or 2, prompt the user to try again
        System.out.print("Shift (1 or 2): ");
        input = kb.nextLine();
        shift = ValidateShift(input);
        while (shift != 1 && shift != 2)
        {
            System.out.print("Invalid shift." +
                    "\nPlease enter a shift. (Day = 1, Night = 2)\n"
                    + "\nShift: ");
            input = kb.nextLine();
            shift = ValidateShift(input);
        }
        
        //worker hourly rate input. has to be validated
        //if a string or negative number is entered, prompt user to try again
        System.out.print("Hourly Rate: ");
        input = kb.nextLine();
        rate = ValidateRate(input);
        while (rate <= 0)
        {
            System.out.print("\nInvalid hourly rate." +
                    "\nPlease enter a positive, hourly rate."
                    + "\nHourly Rate: ");
            input = kb.nextLine();
            rate = ValidateRate(input);
        }
        
        //create the worker object with this info
        ProductionWorker workerOne = new ProductionWorker(name, number,
                                        hireDate, shift, rate);
        
        //return the worker's file to the user as submitted
        System.out.println("\nThe following information has been submitted:");
        System.out.println(workerOne.toString());
        
    }
    
    //to validate the worker's number
    private static boolean ValidateEmpNum(String num)
    {
        boolean valid = true;
        
        if(num.length() != 5) {valid = false;}
        if(!Character.isDigit(num.charAt(0))) {valid = false;}
        if(!Character.isDigit(num.charAt(1))) {valid = false;}
        if(!Character.isDigit(num.charAt(2))) {valid = false;}
        if(num.charAt(3) != '-') {valid = false;}
        if(!Character.isAlphabetic(num.charAt(4))) {valid = false;}
        if(Character.toUpperCase(num.charAt(4)) < 'A') {valid = false;}
        if(Character.toUpperCase(num.charAt(4)) > 'M') {valid = false;}
        
        return valid;
    }
    
    //to validate the worker's shift
       private static int ValidateShift(String input)
    {
        int output;
        try {output = Integer.parseInt(input);}
        catch (Exception ex) {output = -1;}
        return output;
    }
    
    //to validate the worker's pay rate
    private static double ValidateRate(String input)
    {
        double output;
        try {output = Double.parseDouble(input);}
        catch (Exception ex) {output = -1;}
        return output;
    }   
}
