/**
* Here is the Employee class.
* 10-11-2017
* CSC 251 Lab 9 - Employee and ProductionWorker Classes 
* @author Holly Franks
*/
package m3_l3_franksholly;

public class Employee {
    
    private String employeeName;
    private String employeeNumber;
    private String hireDate;
    
    public Employee()
    {
        employeeName = "";
        employeeNumber = "";
        hireDate = "";
    }
    
    public Employee(String name, String num, String date)
    {
        employeeName = name;
        employeeNumber = num;
        hireDate = date;
    }
    
    public void setEmployeeName(String name) {employeeName = name;}
    public void setEmployeeNumber(String num) {employeeNumber = num;}
    public void setHireDate(String date) {hireDate = date;}
    
    public String getEmployeeName() {return employeeName;}
    public String getEmployeeNumber() {return employeeNumber;}
    public String getHireDate() {return hireDate;}
    
    public String toString()
    {
        return "Name: " + employeeName + "\nNo.: " + employeeNumber +
                "\nHired: " + hireDate;   
    }
}
