/**
* This is Lab 7 (BankAccount Class Copy Constructor) in module 2 for Chapter 8.
*       I did go a little overboard. I got really confused with handling exceptions
*       and making the program behave appropriately when hitting "Close" or exit.
*       However, I'm glad I grasped the concept of tokens better through this.
* 9-6-2017
* CSC 251 Lab 7 - BankAccount Class Copy Constructor
* @author Holly Franks
*/
package m2_l1_franksholly;
import java.text.DecimalFormat;
import javax.swing.JOptionPane;

public class M2_L1_FranksHolly {

    public static void main(String[] args) {
        
        String input = "";
        boolean valid = false;
        
        JOptionPane.showMessageDialog(null, "In order to create two accounts," +
                                            " the same amount must be deposited into each" +
                                            " account.");
        while (valid == false) 
        {   
            input = JOptionPane.showInputDialog("How much would you like to deposit to each" +
                                        " account?");
            if (input == null) {System.exit(0);}
            try {Double.parseDouble(input); valid = true;} 
            catch (Exception ex) {valid = false; showErrorDialog();}
        }

        BankAccount account1 = new BankAccount(input);
        BankAccount account2 = new BankAccount(account1);

        while (input != null)
        {
            input = showForm(account1, account2);
            if (input == null) {System.exit(0);}
            input = input.toLowerCase();
            String[] tokens = input.split(" ");

            if (tokens.length == 3)
            {
               if (tokens[0].equals("deposit")) 
               {
                   if (tokens[2].equals("a")) {account1.deposit(tokens[1]);}
                   else if (tokens[2].equals("b")) {account2.deposit(tokens[1]);}
                   else {showErrorDialog();}
               }
               else if (tokens[0].equals("withdraw"))
               {
                  if (tokens[2].equals("a")) {account1.withdraw(tokens[1]);}
                  else if (tokens[2].equals("b")) {account2.withdraw(tokens[1]);}
                  else {showErrorDialog();}
               }
               else {showErrorDialog();}
            }
            else {showErrorDialog();}
        }
    }
    
    public static String showForm(BankAccount account1, BankAccount account2)
    {
        DecimalFormat dollar = new DecimalFormat("#,##0.00");
        return JOptionPane.showInputDialog("The balance in account A is: $" 
                            + dollar.format(account1.getBalance()) +
                            "\nThe balance in account B is: $" 
                            + dollar.format(account2.getBalance()) +
                            "\n\nWhat would you like to do? \n(Ex: Withdraw 200 A)");
    }
    
    public static void showErrorDialog()
    {
        JOptionPane.showMessageDialog(null, "Input is invalid. Try again."); 
    }
    
}
