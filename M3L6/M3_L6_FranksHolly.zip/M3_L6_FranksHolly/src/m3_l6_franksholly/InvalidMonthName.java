/**
* Here is the InvalidMonthName class for Month Class Exceptions.
* 11-06-2017
* CSC 251 Homework 4 - Month Class Exceptions
* @author Holly Franks
*/
package m3_l6_franksholly;

public class InvalidMonthName extends Exception 
{public InvalidMonthName(){super("ERROR: Invalid month name.\n\n");}}