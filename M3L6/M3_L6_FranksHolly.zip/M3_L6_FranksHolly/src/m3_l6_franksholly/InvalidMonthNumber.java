/**
* Here is the InvalidMonthNumber class for Month Class Exceptions.
* 11-06-2017
* CSC 251 Homework 4 - Month Class Exceptions
* @author Holly Franks
*/
package m3_l6_franksholly;

public class InvalidMonthNumber extends Exception 
{public InvalidMonthNumber(){super("ERROR: Invalid month number.\n\n");}}
