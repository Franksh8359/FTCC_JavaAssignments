/**
* InvalidPayRate for Exception Project; meant to catch bad input for payrate.
* 11/5/17
* CSC 251 Lab 10 - Exception Project
* @author Holly Franks
*/
package m3_l5_franksholly;

public class InvalidPayRate extends Exception
{public InvalidPayRate(){super("ERROR: Invalid pay rate.\n\n");}}