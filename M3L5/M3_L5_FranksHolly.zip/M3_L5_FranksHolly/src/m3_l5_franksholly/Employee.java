/**
* Employee class for Exception Project.
* 11/5/17
* CSC 251 Lab 10 - Exception Project
* @author Holly Franks
*/
package m3_l5_franksholly;

public class Employee {
    
    private String employeeName;
    private String employeeNumber;
    private String hireDate;
    
    public Employee()
    {
        employeeName = "";
        employeeNumber = "";
        hireDate = "";
    }
    
    public Employee(String name, String num, String date) throws InvalidEmployeeNumber
    {
        employeeName = name;
        setEmployeeNumber(num);
        hireDate = date;
    }
    
    public void setEmployeeName(String name) {employeeName = name;}
    
    public void setEmployeeNumber(String num) throws InvalidEmployeeNumber
        {if (ValidEmpNum(num)) {employeeNumber = num;}
        else {throw new InvalidEmployeeNumber();}}
    
    public void setHireDate(String date) {hireDate = date;}
    
    public String getEmployeeName() {return employeeName;}
    public String getEmployeeNumber() {return employeeNumber;}
    public String getHireDate() {return hireDate;}
    
    public String toString()
    {
        return "Name: " + employeeName + "\nNo.: " + employeeNumber +
                "\nHired: " + hireDate;   
    }
    
        //to validate the worker's number
    private static boolean ValidEmpNum(String num)
    {
        boolean valid = true;
        
            if(num.length() != 5) {valid = false;}
            else {
            if(!Character.isDigit(num.charAt(0))) {valid = false;}
            if(!Character.isDigit(num.charAt(1))) {valid = false;}
            if(!Character.isDigit(num.charAt(2))) {valid = false;}
            if(num.charAt(3) != '-') {valid = false;}
            if(!Character.isAlphabetic(num.charAt(4))) {valid = false;}
            if(Character.toUpperCase(num.charAt(4)) < 'A') {valid = false;}
            if(Character.toUpperCase(num.charAt(4)) > 'M') {valid = false;}}
        
        return valid;
    }
}
