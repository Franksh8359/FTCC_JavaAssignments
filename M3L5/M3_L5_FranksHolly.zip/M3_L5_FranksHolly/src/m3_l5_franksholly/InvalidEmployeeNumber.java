/**
* InvalidEmployeeNumber for Exception Project; meant to catch bad input for
*               employee number.
* 11/5/17
* CSC 251 Lab 10 - Exception Project
* @author Holly Franks
*/
package m3_l5_franksholly;

public class InvalidEmployeeNumber extends Exception
{public InvalidEmployeeNumber(){super("ERROR: Invalid employee number.\n\n");}}
