/**
* Here is the updated Employee & ProductionWorker program--this time as the
*           Exception Project from page 759. I wanted this to still have a user
*           input interface. It was not easy, but I made it work.
* 11/5/17
* CSC 251 Lab 10 - Exception Project
* @author Holly Franks
*/
package m3_l5_franksholly;
import java.util.*;

public class M3_L5_FranksHolly {

    public static void main(String[] args) 
            throws InvalidEmployeeNumber, InvalidShift, InvalidPayRate
    {
        String input;
        int shift;
        double rate;
        boolean valid = false;
        Scanner kb = new Scanner(System.in);
        
        //while any input is invalid, prompt the user to start over.
        while (!valid)
        {
            try{
                ProductionWorker worker = new ProductionWorker();

                System.out.print("Please enter the following information for the worker: ");

                System.out.print("\nName: ");
                worker.setEmployeeName(kb.nextLine());

                System.out.print("Employee Number: ");
                worker.setEmployeeNumber(kb.nextLine());

                System.out.print("Date Hired: ");
                worker.setHireDate(kb.nextLine());

                System.out.print("Shift (1 or 2): ");
                input = kb.nextLine();
                shift = Integer.parseInt(input);
                worker.setShift(shift);

                System.out.print("Hourly Rate: ");
                input = kb.nextLine();
                rate = Double.parseDouble(input);
                worker.setHourlyRate(rate);

                valid = true;
                System.out.println("\nSUCCESS! The following information has been submitted:");
                System.out.println(worker.toString());
            }
            //realized this catch was also necessary to catch mismatch data types
            catch(IllegalArgumentException e) {System.out.print("ERROR: Data "
                    + "type mismatch.\n\n");}
            catch(InvalidEmployeeNumber e) {System.out.print(e.getMessage());}
            catch(InvalidShift e) {System.out.print(e.getMessage());}
            catch(InvalidPayRate e) {System.out.print(e.getMessage());}
        }
    }   
}
