/**
* ProductionWorker class for Exception Project.
* 11/5/17
* CSC 251 Lab 10 - Exception Project
* @author Holly Franks
*/
package m3_l5_franksholly;
import java.text.DecimalFormat;

public class ProductionWorker extends Employee {
    
    private int shift;
    private double hourlyRate;
    
    public ProductionWorker() throws InvalidEmployeeNumber
    {
        super("", "000-A", "");
        shift = 0;
        hourlyRate = 0.0;
    }
    
    public ProductionWorker(String n, String num, String date, int sh, double r)
            throws InvalidEmployeeNumber, InvalidShift, InvalidPayRate
    {
        super(n, num, date);
        setShift(sh);
        setHourlyRate(r);
    }
    
    public void setShift(int sh) throws InvalidShift
        {if(sh != 1 && sh != 2){throw new InvalidShift();}
        else {shift = sh;}}
    
    public void setHourlyRate(double rate) throws InvalidPayRate
        {if(rate <=0){throw new InvalidPayRate();}
        else {hourlyRate = rate;}}
    
    public int getShift() {return shift;}
    public double getHourlyrate() {return hourlyRate;}
    
    public String toString()
    {
        String shiftName;
        DecimalFormat dollar = new DecimalFormat("#,##0.00");
        
        if (shift == 1) {shiftName = "Day";}
        else if (shift == 2) {shiftName = "Night";}
        else {shiftName = "N/A";}
        
        return super.toString() +
                "\nShift: " + shiftName + "\nHourly Rate: $" + 
                dollar.format(hourlyRate);
    }
}
