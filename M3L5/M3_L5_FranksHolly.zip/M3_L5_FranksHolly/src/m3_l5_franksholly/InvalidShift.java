/**
* InvalidShift for Exception Project; meant to catch bad input for shift.
* 11/5/17
* CSC 251 Lab 10 - Exception Project
* @author Holly Franks
*/
package m3_l5_franksholly;

public class InvalidShift extends Exception
{public InvalidShift(){super("ERROR: Invalid shift.\n\n");}}
