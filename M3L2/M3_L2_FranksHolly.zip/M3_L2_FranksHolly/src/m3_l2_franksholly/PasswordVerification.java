/**
* The PasswordVerification class for the Password Verifier assignment.
* 10-16-2017
* CSC 251 Homework 2 - Password Verifier
* @author Holly Franks
*/
package m3_l2_franksholly;

public class PasswordVerification {
    
    private String password;
    
    PasswordVerification(String input)
    {
        password = input;
    }
    
    public boolean VerifyPassword()
    {
        boolean length = false;
        boolean digit = false;
        boolean upper = false;
        boolean lower = false;
        
        if (password.length() >= 6) 
        {   length = true;                
            for (int i = 0; i < password.length(); i++)
            {
                if (Character.isDigit(password.charAt(i))) {digit = true;}
                if (Character.isLowerCase(password.charAt(i))) {lower = true;}
                if (Character.isUpperCase(password.charAt(i))) {upper = true;}
            }
        }
        
        if (length && digit && lower && upper) {return true;}
        else {return false;}
    }   
}
