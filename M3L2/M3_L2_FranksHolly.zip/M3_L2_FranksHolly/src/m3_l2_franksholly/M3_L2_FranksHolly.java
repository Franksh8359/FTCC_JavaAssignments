/**
* This is the Password Verifier assignment from module 3.
* 10-16-2017
* CSC 251 Homework 2 - Password Verifier
* @author Holly Franks
*/
package m3_l2_franksholly;
import javax.swing.JOptionPane;

public class M3_L2_FranksHolly {

    public static void main(String[] args) {
        
        boolean valid = false;
        String input = ShowInputField();
        PasswordVerification pass = new PasswordVerification(input);
        valid = pass.VerifyPassword();
        
        //while the password is invalid, prompt user for another attempt
        //check the new attempt
        while (!valid)
        {
            JOptionPane.showMessageDialog(null, input + "\n\nInvalid password."
                                                + "  Please try again.");
            input = ShowInputField();
            PasswordVerification passTwo = new PasswordVerification(input);
            valid = passTwo.VerifyPassword();
        }
        
        //if the password ever returns valid, let the user know it's valid
        JOptionPane.showMessageDialog(null, "Password accepted. Welcome to"
                                            + " Amazon!");    
    }
    
    //to prevent redundant code in while loop & also check use response
    public static String ShowInputField()
    {
        String input = JOptionPane.showInputDialog(
                          "CREATE YOUR AMAZON PASSWORD\n" +
                          "The password should contain:\n" +
                          "*At least six characters.\n" +
                          "*At least one uppercase letter.\n" +
                          "*At least one lowercase letter.\n" +
                          "*At least one digit.");
        if (input == null) {System.exit(0);}
        return input;
    }
}
