/**
* Main class.
* 11-27-2017
* CSC 251 Lab 12 - Monthly Sales Tax
* @author Holly Franks
*/
package monthlysalestax_franksholly;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Mio
 */
public class MonthlySalesTax_FranksHolly extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("MonthlySalesTax_FranksHolly.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setTitle("Monthly Sales Tax Calculator");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
