/**
* Controller class.
* 11-27-2017
* CSC 251 Lab 12 - Monthly Sales Tax
* @author Holly Franks
*/
package monthlysalestax_franksholly;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import java.text.DecimalFormat;

public class MonthlySalesTaxController {

    @FXML
    private Button exitButton;

    @FXML
    private TextField totalField;

    @FXML
    private TextField stateField;

    @FXML
    private TextField salesField;

    @FXML
    private Button calculateButton;

    @FXML
    private TextField countyField;

    public void initialize(){}
    
    public void calculateButtonListener() {
        
        final double COUNTYRATE = .02;
        final double STATERATE = .04;
        double countyTax, stateTax, total;
        
        //try-catch for bad input; let user know in output field
        try{
            double input = Double.parseDouble(salesField.getText());
            countyTax = COUNTYRATE * input;
            stateTax = STATERATE * input;
            total = countyTax + stateTax;
            
            DecimalFormat dollar = new DecimalFormat("#,##0.00");
            countyField.setText("$" + dollar.format(countyTax));
            stateField.setText("$" + dollar.format(stateTax));
            totalField.setText("$" + dollar.format(total));
        }
        catch (Exception ex) {totalField.setText("Error! Numbers only.");}
    }
    
    public void exitButtonListener() {
        System.exit(0);
    }

}

