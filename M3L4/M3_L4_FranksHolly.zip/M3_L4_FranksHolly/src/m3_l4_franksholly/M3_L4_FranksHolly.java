/**
* This is the Course Grades assignment. Honestly, this one was tough for me.
*   I wanted to make the pass/fail exam subclass off of the FinalExam to prevent
*   redundancy, but I couldn't exactly figure out how to make it work.
*   For the main class, I decided to let the user input data to test the code.
* 11-06-2017
* CSC 251 Homework 3 - Course Grades
* @author Holly Franks
*/
package m3_l4_franksholly;
import java.util.*;

public class M3_L4_FranksHolly {

    public static void main(String[] args) {
        
        Scanner kb = new Scanner(System.in);
        double input = 0;
        double[] essayScores = {0, 0, 0, 0}; //array to hold essay scores
        boolean valid = false;
        
        System.out.println("Enter the following grades for the student:");
        
        //while input is invalid.. keep asking for new input
        while (!valid)
        {
            System.out.print("Graded Lab: ");
            try{input = Double.parseDouble(kb.nextLine()); valid = true;}
            catch (Exception e) {System.out.println("ERROR: Invalid input. "
                    + "Try again."); }
        }
        //once input is valid, create the object with it
        GradedActivity lab = new GradedActivity(); lab.setScore(input);
        //then set valid back to false for next round of input. repeat
        valid = false;
        
        while (!valid)
        {
            System.out.print("Pass/Fail Exam (no. Missed): ");
            try{input = Double.parseDouble(kb.nextLine()); valid = true;}
            catch (Exception e) {System.out.println("ERROR: Invalid input. "
                    + "Try again."); }
        }
        GradedActivity exam = new PassFailExam(input);
        valid = false;
        
        System.out.println("Essay (in depth): ");
        while (!valid)
        {
            System.out.print(">Grammar: ");
            try{input = Double.parseDouble(kb.nextLine()); valid = true;
            essayScores[0] = input;
            }
            catch (Exception e) {System.out.println("ERROR: Invalid input. "
                    + "Try again."); }
        }
        valid = false;
        
        while (!valid)
        {
            System.out.print(">Spelling: ");
            try{input = Double.parseDouble(kb.nextLine()); valid = true;
            essayScores[1] = input;
            }
            catch (Exception e) {System.out.println("ERROR: Invalid input. "
                    + "Try again."); }
        }
        valid = false; 
        
        while (!valid)
        {
            System.out.print(">Length: ");
            try{input = Double.parseDouble(kb.nextLine()); valid = true;
            essayScores[2] = input;
            }
            catch (Exception e) {System.out.println("ERROR: Invalid input. "
                    + "Try again."); }
        }
        valid = false;
        
        while (!valid)
        {
            System.out.print(">Content: ");
            try{input = Double.parseDouble(kb.nextLine()); valid = true;
            essayScores[3] = input;
            }
            catch (Exception e) {System.out.println("ERROR: Invalid input. "
                    + "Try again."); }
        }
        GradedActivity essay = new Essay(essayScores);
        valid = false;
        
        while (!valid)
        {
            System.out.print("Final Exam (no. Missed): ");
            try{input = Double.parseDouble(kb.nextLine()); valid = true;}
            catch (Exception e) {System.out.println("ERROR: Invalid input. "
                    + "Try again."); }
        }
        GradedActivity finalExam = new FinalExam(input);
        
        //finally, create the coursegrades array... then display the results
        CourseGrades courseGrades = new CourseGrades(lab, exam, essay, finalExam);
        System.out.println(courseGrades.toString());
        
        //when I read the criteria for the pass/fail exam, I figured it was
        //  saying 70+ is an A, and anything under 70 was an F. Therefore,
        //  I overrode the getGrade method in that class to display such results
    }
    
}
