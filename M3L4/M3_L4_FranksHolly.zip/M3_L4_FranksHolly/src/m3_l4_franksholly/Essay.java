/**
* Essay class; Essay object that extends GradedActivity.
* 11-06-2017
* CSC 251 Homework 3 - Course Grades
* @author Holly Franks
*/
package m3_l4_franksholly;

public class Essay extends GradedActivity{
    
    private double grammar, spelling, length, content;
    
    public Essay(double[] scores)
    {
        if (scores[0] >= 0) {grammar = scores[0];} else {grammar = 0;}
        if (scores[1] >= 0) {spelling = scores[1];} else {spelling = 0;}
        if (scores[2] >= 0) {length = scores[2];} else {length = 0;}
        if (scores[3] >= 0) {content = scores[3];} else {content = 0;}
        setScore(grammar + spelling + length + content);
    }
    
    public double getGrammar() {return grammar;}
    public double getSpelling() {return spelling;}
    public double getLength() {return length;}
    public double getContent() {return content;}
    
}
