/**
* CourseGrades class; array of the four graded assignments.
* 11-06-2017
* CSC 251 Homework 3 - Course Grades
* @author Holly Franks
*/
package m3_l4_franksholly;

public class CourseGrades {
    
    private GradedActivity grades[]= new GradedActivity[4];
    
    public CourseGrades(GradedActivity lab, GradedActivity exam, 
        GradedActivity essay, GradedActivity fexam){
        setLab(lab);
        setPassFailExam(exam);
        setEssay(essay);
        setFinalExam(fexam);       
    }
    
    public void setLab(GradedActivity lab){grades[0] = lab;}
    public void setPassFailExam(GradedActivity exam){grades[1] = exam;}
    public void setEssay(GradedActivity essay){grades[2] = essay;}
    public void setFinalExam(GradedActivity exam){grades[3] = exam;}
    
    public String toString()
    {
        String output = "\nGrades:\n";  
        for(int i=0; i<4; i++) 
        {output+= grades[i].getGrade() + " - " + grades[i].getScore() + "\n";}      
        return output;
    }
    
}
