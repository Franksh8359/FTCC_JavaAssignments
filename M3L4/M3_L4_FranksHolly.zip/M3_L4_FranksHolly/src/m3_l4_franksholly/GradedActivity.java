/**
* GradedActivity class; basis of graded activities (exams, essays, etc).
* 11-06-2017
* CSC 251 Homework 3 - Course Grades
* @author Holly Franks
*/
package m3_l4_franksholly;

public class GradedActivity {
    
    private double score;
    
    public void setScore(double s) {if(s<0){score = 0;} else {score = s;}}
    public double getScore() {return score;}
    public char getGrade()
    {
        if(score >= 90) {return 'A';}
        else if(score >= 80) {return 'B';}
        else if(score >= 70) {return 'C';}
        else if(score >= 60) {return 'D';}
        else {return 'F';}
    }
    
}
