/**
* FinalExam class; FinalExam object that extends GradedActivity
* 11-06-2017
* CSC 251 Homework 3 - Course Grades
* @author Holly Franks
*/
package m3_l4_franksholly;

public class FinalExam extends GradedActivity {

    private final int NUMQUESTIONS = 50;
    private double pointsEach;
    private double numMissed;
    
    public FinalExam(double missed)
    {
        if (missed < 0) {numMissed = 0;}
        else if (missed > NUMQUESTIONS) {numMissed = NUMQUESTIONS;}
        else{numMissed = missed;}
        pointsEach = 100.0 / NUMQUESTIONS;
        double numericScore = 100.0 - (numMissed * pointsEach);
        setScore(numericScore);
    }
    
    public double getPointsEach() {return pointsEach;}
    public double getNumMissed() {return numMissed;}
    
}
