/**
* This is the blueprint for tables made in the Pizzeria project.
* 12/11/2017
* CSC 251 Project 2 -Pizzeria
* @author Holly Franks
*/
package pizzeria_franksholly;
import java.sql.*;

public class PizzeriaTable {
    
    final String DB_URL = "jdbc:derby://localhost:1527/PizzeriaDB";
    private String tableName = "";
    private String colName = "";

    public PizzeriaTable(String tName, String cName)
    {
        //constructor creates a table with description and price columns
       try
        {
           Connection con = DriverManager.getConnection(DB_URL);
           Statement stmt = con.createStatement();
           tableName = tName;
           colName = cName;
           String sqlDrop1 = "DROP TABLE "+tName;
           stmt.execute(sqlDrop1);         
           String s1 = "CREATE TABLE "+tableName+"("+colName+" CHAR(25), Price DOUBLE)";
           stmt.execute(s1);

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }

    public void insertRecord(String str, double price)
    {
        try
        {
            Connection con = DriverManager.getConnection(DB_URL);
            Statement stmt = con.createStatement();

            String add = "INSERT INTO "+tableName+"("+colName+", Price) VALUES("+str+", "+price+")";
            stmt.executeUpdate(add);

        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        } 
    }   
}
