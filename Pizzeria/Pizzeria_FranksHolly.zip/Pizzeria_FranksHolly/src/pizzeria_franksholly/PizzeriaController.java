/**
* This is the (very messy) controller for the Pizzeria app.
*       Admittedly, this could have been cleaner. Not my best work.
* 12/11/2017
* CSC 251 Project 2 -Pizzeria
* @author Holly Franks
*/
package pizzeria_franksholly;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import java.sql.*;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.text.DecimalFormat;

public class PizzeriaController {
    
    @FXML
    private Label totalLabel;
    
    @FXML
    private TextField crustField;
    
    @FXML
    private TextField sizeField;
    
    @FXML
    private Button addButton;
    
    @FXML
    private Button removeButton;
    
    @FXML
    private Button submitButton;
        
    @FXML
    private Label sizeLabel;
    
    @FXML
    private Label crustLabel;
    
    @FXML
    private Label toppingsLabel;
    
    @FXML
    private Label orderPlacedLabel;
        
    @FXML
    private Label totalDescLabel;
    
    @FXML
    private ListView<String> selectionListBox;
    
    @FXML
    private ListView<String> orderListBox;
    
    @FXML
    private ListView<String> toppingsListBox;
     
    @FXML
    private ChoiceBox<String> sizeChoiceBox;
    
    @FXML
    private ChoiceBox<String> crustChoiceBox;

    @FXML
    void initialize(ActionEvent event) {

    }
    
    final String DB_URL = "jdbc:derby://localhost:1527/PizzeriaDB";
    
    public void initialize(){
    
        try{
        Connection conn = DriverManager.getConnection(DB_URL);
        
        Statement stmt = conn.createStatement();
        String sqlStatement = "SELECT SIZE FROM APP.PIZZASIZE";
        ResultSet result = stmt.executeQuery(sqlStatement);
        while (result.next()) {sizeChoiceBox.getItems().add(result.getString("SIZE"));}
        conn.close();
            }
        catch(Exception ex) {sizeChoiceBox.getItems().add("ERROR");}
        
        try{
        Connection conn = DriverManager.getConnection(DB_URL);
        
        Statement stmt = conn.createStatement();
        String sqlStatement = "SELECT CRUST FROM APP.PIZZACRUST";
        ResultSet result = stmt.executeQuery(sqlStatement);
        while (result.next()) {crustChoiceBox.getItems().add(result.getString("CRUST"));}
        conn.close();
            }
        catch(Exception ex) {crustChoiceBox.getItems().add("ERROR");}
        
        try{
        Connection conn = DriverManager.getConnection(DB_URL);
        
        Statement stmt = conn.createStatement();
        String sqlStatement = "SELECT TOPPING FROM APP.PIZZATOPPINGS";
        ResultSet result = stmt.executeQuery(sqlStatement);
        while (result.next()) {selectionListBox.getItems().add(result.getString("TOPPING"));}
        conn.close();
            }
        catch(Exception ex) {selectionListBox.getItems().add("ERROR");}
    }
    
    
    //adds an item to the order list box, removes the item from the main list
    public void addButtonListener(){
        if (orderListBox.getItems().size() <= 5 && selectionListBox.getSelectionModel().getSelectedItem() != null)
        {   orderListBox.getItems().add(selectionListBox.getSelectionModel().getSelectedItem());
            selectionListBox.getItems().remove(selectionListBox.getSelectionModel().getSelectedIndex());
        }
    }
    
    //removes an item from the order list, adds it back to main list
    public void removeButtonListener(){
        if(orderListBox.getSelectionModel().getSelectedItem() != null){
                selectionListBox.getItems().add(orderListBox.getSelectionModel().getSelectedItem());
                orderListBox.getItems().remove(orderListBox.getSelectionModel().getSelectedIndex());
            }
    }

    //submits the order
    public void submitButtonListener(){
        
        //accumulator for price
        double total = 0;
        
        //fetch selected size price from db
        try {
            Connection con = DriverManager.getConnection(DB_URL);   
            Statement stmt = con.createStatement();
            String selected = sizeChoiceBox.getSelectionModel().getSelectedItem();
            String sqlStatement = "SELECT PRICE FROM APP.PIZZASIZE WHERE SIZE = '"+selected+"'";
            ResultSet result = stmt.executeQuery(sqlStatement);
            while (result.next()) {total += result.getDouble("PRICE");}
            con.close();  
        }
        catch(Exception ex){System.out.println("ERROR adding pizza size.");}

        //fetch selected crust price from db
        try {
            Connection con = DriverManager.getConnection(DB_URL);   
            Statement stmt = con.createStatement();
            String selected = crustChoiceBox.getSelectionModel().getSelectedItem();
            String sqlStatement = "SELECT PRICE FROM APP.PIZZACRUST WHERE CRUST = '"+selected+"'";
            ResultSet result = stmt.executeQuery(sqlStatement);
            while (result.next()) {total += result.getDouble("PRICE");}
            con.close();  
        }
        catch(Exception ex){System.out.println("ERROR adding pizza crust.");}
        
        //for each topping in list, fetch its price, add to accumulator
        try {
            Connection con = DriverManager.getConnection(DB_URL);   
            Statement stmt = con.createStatement();
            for (int i = 0; i < orderListBox.getItems().size(); i++)
            {
                String selected = orderListBox.getItems().get(i);
                String sqlStatement = "SELECT PRICE FROM APP.PIZZATOPPINGS WHERE TOPPING = '"+selected+"'";
                ResultSet result = stmt.executeQuery(sqlStatement);
                while (result.next()) {total += result.getDouble("PRICE");}
            }
            con.close();
        }
        catch(Exception ex){System.out.println("ERROR adding pizza toppings.");}
        
        //disable and do away with certain elements on app form
        sizeChoiceBox.setDisable(true);
        crustChoiceBox.setDisable(true);
        selectionListBox.setDisable(true);
        orderListBox.setDisable(true);
        addButton.setDisable(true);
        removeButton.setDisable(true);
        submitButton.setDisable(true);
        sizeChoiceBox.setVisible(false);
        crustChoiceBox.setVisible(false);
        selectionListBox.setVisible(false);
        orderListBox.setVisible(false);
        addButton.setVisible(false);
        removeButton.setVisible(false);
        submitButton.setVisible(false);
        
        //enable and edit certain elements on app form
        sizeField.setText(sizeChoiceBox.getSelectionModel().getSelectedItem());
        crustField.setText(crustChoiceBox.getSelectionModel().getSelectedItem());
        sizeLabel.setText("Size Ordered:");
        crustField.setText(crustChoiceBox.getSelectionModel().getSelectedItem());
        crustLabel.setText("Crust Ordered:");
        toppingsLabel.setText("Toppings Ordered:");
        DecimalFormat dollar = new DecimalFormat("#,##0.00");
        totalLabel.setText("$"+dollar.format(total));
        
        for (int i = 0; i < orderListBox.getItems().size(); i++)
            {
                toppingsListBox.getItems().add(orderListBox.getItems().get(i));
            }
        
        sizeField.setVisible(true);
        crustField.setVisible(true);
        orderPlacedLabel.setVisible(true);
        totalDescLabel.setVisible(true);
        totalLabel.setVisible(true);
        toppingsListBox.setVisible(true);
        
    }   
}
