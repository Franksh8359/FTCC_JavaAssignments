/**
* This is the main class for the Pizzeria app. On start, three database tables
*       are created and populated using the PizzeriaTable class blueprint.
* 12/11/2017
* CSC 251 Project 2 -Pizzeria
* @author Holly Franks
*/
package pizzeria_franksholly;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.sql.*;
public class Pizzeria_FranksHolly extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("Pizzeria_FranksHolly.fxml"));
        
        Scene scene = new Scene(root);       
        
        stage.setTitle("Pizerria Order Submission");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        final String DB_URL = "jdbc:derby://localhost:1527/PizzeriaDB";
        
        //create and populate size table
        try {
        Connection con = DriverManager.getConnection(DB_URL);   
        Statement stmt = con.createStatement();
        PizzeriaTable sizeTable = new PizzeriaTable("PizzaSize", "Size");
        sizeTable.insertRecord("'Small'", 7.00);
        sizeTable.insertRecord("'Medium'", 9.00);
        sizeTable.insertRecord("'Large'", 11.00);
        con.close();  
        }
        catch(Exception ex){System.out.println("ERROR initializing Pizza Size Table.");}
        
        //create and populate crust table
        try {
        Connection con = DriverManager.getConnection(DB_URL);         
        Statement stmt = con.createStatement();   
        PizzeriaTable crustTable = new PizzeriaTable("PizzaCrust", "Crust");
        crustTable.insertRecord("'Thin'", 0);
        crustTable.insertRecord("'Hand-tossed'", 0);
        crustTable.insertRecord("'Deep-dish'", 0);
        crustTable.insertRecord("'Stuffed-crust'", 0);
        crustTable.insertRecord("'Gut-blaster'", 0);
        con.close();  
        }
        catch(Exception ex){System.out.println("ERROR initializing Pizza Crust Table.");}
        
        //create and populate Toppings table
        try {
        Connection con = DriverManager.getConnection(DB_URL);         
        Statement stmt = con.createStatement();   
        PizzeriaTable toppingsTable = new PizzeriaTable("PizzaToppings", "Topping");
        toppingsTable.insertRecord("'Pepperoni'", 0.50);
        toppingsTable.insertRecord("'Sausage'", 0.50);
        toppingsTable.insertRecord("'Ham'", 0.50);
        toppingsTable.insertRecord("'Bacon'", 0.50);
        toppingsTable.insertRecord("'Chicken'", 0.50);
        toppingsTable.insertRecord("'Hamburger'", 0.50);
        toppingsTable.insertRecord("'Extra Cheese'", 0.50);
        toppingsTable.insertRecord("'Onions'", 0.50);
        toppingsTable.insertRecord("'Green Peppers'", 0.50);
        toppingsTable.insertRecord("'Mushrooms'", 0.50);
        toppingsTable.insertRecord("'Black Olives'", 0.50);
        toppingsTable.insertRecord("'Pineapple'", 0.50);
        toppingsTable.insertRecord("'Sliced Tomatoes'", 0.50);
        toppingsTable.insertRecord("'Feta Cheese'", 0.50);   
        con.close();  
        }
        catch(Exception ex){System.out.println("ERROR initializing Pizza Toppings Table.");}
       
        
        launch(args);
    }
    
}
